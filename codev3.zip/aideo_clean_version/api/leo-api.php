<?php
// 🦁 Léo IA API - Optimisé pour Hostinger
// API simple pour l'intégration Aidéo + Léo RAG

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Gestion CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

class LeoAPI {
    private $apiKey;
    private $isDevelopment;
    
    public function __construct() {
        $this->apiKey = $_ENV['LEO_API_KEY'] ?? 'demo-key';
        $this->isDevelopment = ($_ENV['ENVIRONMENT'] ?? 'production') === 'development';
    }
    
    public function handleRequest() {
        try {
            $method = $_SERVER['REQUEST_METHOD'];
            
            switch ($method) {
                case 'POST':
                    return $this->handlePost();
                case 'GET':
                    return $this->handleGet();
                default:
                    return $this->error('Méthode non supportée', 405);
            }
            
        } catch (Exception $e) {
            return $this->error('Erreur serveur: ' . $e->getMessage(), 500);
        }
    }
    
    private function handlePost() {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            return $this->error('Données JSON invalides', 400);
        }
        
        $action = $input['action'] ?? 'chat';
        
        switch ($action) {
            case 'chat':
                return $this->handleChat($input);
            case 'health':
                return $this->healthCheck();
            default:
                return $this->error('Action non supportée', 400);
        }
    }
    
    private function handleGet() {
        $path = $_GET['path'] ?? '';
        
        switch ($path) {
            case 'health':
            case '':
                return $this->healthCheck();
            case 'stats':
                return $this->getStats();
            default:
                return $this->error('Endpoint non trouvé', 404);
        }
    }
    
    private function handleChat($input) {
        $message = trim($input['message'] ?? '');
        $context = $input['context'] ?? [];
        $sessionId = $input['session_id'] ?? $this->generateSessionId();
        
        if (empty($message)) {
            return $this->error('Message requis', 400);
        }
        
        try {
            // Traiter le message avec notre système intelligent
            $response = $this->processMessage($message, $context, $sessionId);
            
            return $this->success([
                'answer' => $response['answer'],
                'suggestions' => $response['suggestions'] ?? [],
                'actions' => $response['actions'] ?? [],
                'confidence' => $response['confidence'] ?? 0.8,
                'session_id' => $sessionId,
                'timestamp' => date('c')
            ]);
            
        } catch (Exception $e) {
            return $this->error('Erreur traitement message: ' . $e->getMessage(), 500);
        }
    }
    
    private function processMessage($message, $context, $sessionId) {
        $messageLower = strtolower($message);
        
        // Log des messages pour debug
        if ($this->isDevelopment) {
            error_log("Léo Chat - Session: $sessionId - Message: $message");
        }
        
        // Détection des patterns et réponses intelligentes
        $patterns = $this->getResponsePatterns();
        
        foreach ($patterns as $pattern => $responseConfig) {
            if (preg_match($pattern, $messageLower, $matches)) {
                return $this->buildResponse($responseConfig, $matches, $message);
            }
        }
        
        // Réponse par défaut intelligente
        return $this->getDefaultResponse();
    }
    
    private function getResponsePatterns() {
        return [
            // Questions d'impôt précises
            '/impôt.*(\d+).*€.*(célibataire|couple|seul|marié)/i' => [
                'type' => 'calculation',
                'function' => 'calculateTax'
            ],
            
            '/calcul.*impôt.*(\d+)/i' => [
                'type' => 'calculation',
                'function' => 'calculateTax'
            ],
            
            // Questions micro-entreprise
            '/micro.*(entreprise|auto).*(\d+).*€?/i' => [
                'type' => 'micro_entreprise',
                'function' => 'microAnalysis'
            ],
            
            '/ca.*(\d+).*(euros?|€).*(service|commerce|libéral)/i' => [
                'type' => 'ca_analysis',
                'function' => 'analyzeCA'
            ],
            
            // Questions TVA
            '/tva.*(franchise|seuil|régime)/i' => [
                'type' => 'tva_info',
                'function' => 'tvaInfo'
            ],
            
            // Questions étudiants
            '/(étudiant|apprenant|études|université)/i' => [
                'type' => 'student_info',
                'function' => 'studentInfo'
            ],
            
            // Questions optimisation
            '/optimi(s|z)ation|économi(s|er)|réduction.*impôt/i' => [
                'type' => 'optimization',
                'function' => 'optimizationAdvice'
            ],
            
            // Questions EURL/SASU
            '/(eurl|sasu|sarl|sas).*(\d+).*€?/i' => [
                'type' => 'company_structure',
                'function' => 'companyAdvice'
            ],
            
            // Questions logement/APL
            '/(apl|aide.*logement|logement)/i' => [
                'type' => 'housing',
                'function' => 'housingInfo'
            ]
        ];
    }
    
    private function buildResponse($config, $matches, $originalMessage) {
        $function = $config['function'];
        return $this->$function($matches, $originalMessage);
    }
    
    private function calculateTax($matches, $message) {
        $revenu = intval($matches[1]);
        $situation = $matches[2] ?? 'célibataire';
        
        $estimation = $this->estimateTax($revenu, $situation);
        
        return [
            'answer' => "
                <div class='tax-response'>
                    <h4>💰 Estimation impôt sur le revenu</h4>
                    <p><strong>Revenu:</strong> $revenu €</p>
                    <p><strong>Situation:</strong> " . ucfirst($situation) . "</p>
                    <p><strong>Impôt estimé:</strong> {$estimation['amount']} €</p>
                    <p><strong>Taux effectif:</strong> {$estimation['rate']}%</p>
                    
                    <div class='advice-box'>
                        <h5>💡 Conseils d'optimisation :</h5>
                        <ul>
                            <li>Frais réels vs abattement 10%</li>
                            <li>Déclaration commune (si couple)</li>
                            <li>Investissements déductibles (Pinel, PER)</li>
                        </ul>
                    </div>
                </div>
            ",
            'suggestions' => [
                "Optimisation pour $revenu €",
                "Frais réels vs abattement",
                "Couple à revenus différents"
            ],
            'confidence' => 0.85
        ];
    }
    
    private function microAnalysis($matches, $message) {
        $ca = intval($matches[2]);
        
        if ($ca < 37700) {
            $reponse = "✅ <strong>Micro-entreprise recommandée !</strong><br><br>";
            $reponse .= "• CA de $ca € (sous le seuil)<br>";
            $reponse .= "• Charges sociales: 22% pour les services<br>";
            $reponse .= "• Franchise TVA jusqu'à 37 700 €<br>";
            $reponse .= "• Comptabilité simplifiée<br><br>";
            $reponse .= "<strong>Avantages :</strong> Simplicité administrative, charges proportionnelles au CA.";
            
        } else {
            $reponse = "⚠️ <strong>Micro-entreprise non recommandée</strong><br><br>";
            $reponse .= "• CA de $ca € (au-dessus du seuil)<br>";
            $reponse .= "• Dépassement du plafond micro (37 700 €)<br>";
            $reponse .= "• Considérez l'EURL ou la SASU<br><br>";
            $reponse .= "<strong>Alternatives :</strong> EURL (impôt société) ou SASU (tns).";
        }
        
        return [
            'answer' => $reponse,
            'suggestions' => [
                "Seuil micro 2024",
                "EURL vs SASU",
                "Charges sociales comparatif"
            ],
            'actions' => [
                ['text' => '📊 Simuler mes charges', 'url' => 'dashboard.html'],
                ['text' => '📚 Guide EURL/SASU', 'url' => 'fiches.html']
            ],
            'confidence' => 0.9
        ];
    }
    
    private function tvaInfo($matches, $message) {
        return [
            'answer' => "
                <h4>📊 Régime TVA 2024</h4>
                <div class='tva-info'>
                    <p><strong>Franchise de base :</strong></p>
                    <ul>
                        <li>Services : 37 700 €</li>
                        <li>Commerce : 91 400 €</li>
                        <li>Libéral : 37 700 €</li>
                    </ul>
                    
                    <p><strong>Au-dessus des seuils :</strong></p>
                    <ul>
                        <li>⚠️ Régime réel obligatoire</li>
                        <li>TVA collectée à déclarer</li>
                        <li>TVA déductible récupérable</li>
                    </ul>
                </div>
            ",
            'suggestions' => [
                "Calcul franchise TVA",
                "Régime réel simplifié",
                "TVA déductible conseils"
            ],
            'confidence' => 0.9
        ];
    }
    
    private function studentInfo($matches, $message) {
        return [
            'answer' => "
                <h4>🎓 Avantages fiscaux étudiant</h4>
                <div class='student-benefits'>
                    <p><strong>Revenus exonérés :</strong> Jusqu'à 4 884 € par an</p>
                    <p><strong>APL logement :</strong> 100-400 € selon situation</p>
                    <p><strong>Frais déductibles :</strong> Transport, matériel, formation</p>
                    <p><strong>CNCC :</strong> Exonération si revenus < 4 884 €</p>
                </div>
            ",
            'suggestions' => [
                "APL maximum Paris",
                "Déclaration première année",
                "Étudiant entrepreneur"
            ],
            'actions' => [
                ['text' => '📚 Fiche complète étudiants', 'url' => 'fiches-content/aides-etudiantes.html']
            ],
            'confidence' => 0.85
        ];
    }
    
    private function optimizationAdvice($matches, $message) {
        return [
            'answer' => "
                <h4>💡 Optimisation fiscale</h4>
                <div class='optimization-tips'>
                    <p><strong>Stratégies principales :</strong></p>
                    <ul>
                        <li>🏠 Investissement locatif (Pinel, Denormandie)</li>
                        <li>💰 Plan Épargne Retraite (PER)</li>
                        <li>🎁 Dons aux associations (66% déductible)</li>
                        <li>💑 Déclaration commune (couple à revenus différents)</li>
                        <li>📈 Frais réels vs abattement 10%</li>
                    </ul>
                </div>
            ",
            'suggestions' => [
                "Couple à revenus différents",
                "Investissement Pinel 2024",
                "PER vs assurance-vie"
            ],
            'confidence' => 0.8
        ];
    }
    
    private function companyAdvice($matches, $message) {
        return [
            'answer' => "
                <h4>🏢 Choix du statut d'entreprise</h4>
                <div class='company-choices'>
                    <p><strong>EURL :</strong></p>
                    <ul>
                        <li>Impôt sur les sociétés (15% puis 25%)</li>
                        <li>Protection sociale complète</li>
                        <li>Pas de plafond de CA</li>
                    </ul>
                    
                    <p><strong>SASU :</strong></p>
                    <ul>
                        <li>Salarié (chômage, retraite)</li>
                        <li>Charges sociales plus élevées</li>
                        <li>Simplicité administrative</li>
                    </ul>
                </div>
            ",
            'suggestions' => [
                "EURL vs SASU comparatif",
                "Charges sociales détaillées",
                "Optimisation rémunération"
            ],
            'confidence' => 0.85
        ];
    }
    
    private function housingInfo($matches, $message) {
        return [
            'answer' => "
                <h4>🏠 Aides au logement</h4>
                <div class='housing-aids'>
                    <p><strong>APL (2024) :</strong></p>
                    <ul>
                        <li>Étudiant: 100-300 €/mois</li>
                        <li>Actif: 150-400 €/mois</li>
                        <li>Selon revenus et loyer</li>
                    </ul>
                    
                    <p><strong>Conditions :</strong></p>
                    <ul>
                        <li>Revenus < aux plafonds</li>
                        <li>Loyer < aux plafonds</li>
                        <li>CDD/CDI ou replaces</li>
                    </ul>
                </div>
            ",
            'suggestions' => [
                "Simulation APL en ligne",
                "Plafonds APL 2024",
                "Dossier APL optimisé"
            ],
            'confidence' => 0.9
        ];
    }
    
    private function getDefaultResponse() {
        return [
            'answer' => "
                <div class='default-response'>
                    <h4>🦁 Bonjour ! Je suis Léo, votre expert fiscal Aidéo</h4>
                    <p>Je peux vous aider avec :</p>
                    <ul>
                        <li>📊 <strong>Calcul d'impôt</strong> - Dites-moi votre revenu !</li>
                        <li>🏢 <strong>Statut d'entreprise</strong> - Micro, EURL, SASU ?</li>
                        <li>💡 <strong>Optimisation</strong> - Réduire vos impôts légalement</li>
                        <li>📈 <strong>TVA & charges</strong> - Régimes et seuils 2024</li>
                        <li>🏠 <strong>Logement</strong> - APL, Pinel, investissement</li>
                    </ul>
                    <p><em>Posez-moi une question précise pour de meilleurs conseils ! 💬</em></p>
                </div>
            ",
            'suggestions' => [
                "Calcul impôt 40 000€",
                "Micro vs EURL 30k€ ?",
                "Seuil TVA 2024",
                "Optimisation couple"
            ],
            'confidence' => 0.7
        ];
    }
    
    private function estimateTax($revenu, $situation) {
        // Barème 2024 simplifié
        $quotient = 1;
        if (strpos($situation, 'couple') !== false || strpos($situation, 'marié') !== false) {
            $quotient = 2;
        }
        
        $revenu_quotient = $revenu / $quotient;
        
        if ($revenu_quotient <= 11294) {
            $impot = 0;
            $taux = 0;
        } elseif ($revenu_quotient <= 28797) {
            $impot = ($revenu_quotient - 11294) * 0.11;
            $taux = 11;
        } elseif ($revenu_quotient <= 82341) {
            $impot = (28797 - 11294) * 0.11 + ($revenu_quotient - 28797) * 0.30;
            $taux = 30;
        } else {
            $impot = (28797 - 11294) * 0.11 + (82341 - 28797) * 0.30 + ($revenu_quotient - 82341) * 0.41;
            $taux = 41;
        }
        
        $impot_total = $impot * $quotient;
        $taux_effectif = $revenu > 0 ? round(($impot_total / $revenu) * 100, 1) : 0;
        
        return [
            'amount' => number_format($impot_total, 0, ',', ' '),
            'rate' => $taux_effectif
        ];
    }
    
    private function analyzeCA($matches, $message) {
        $ca = intval($matches[1]);
        $activite = $matches[3] ?? 'services';
        
        return $this->microAnalysis(['', '', $ca], $message);
    }
    
    private function healthCheck() {
        return $this->success([
            'status' => 'healthy',
            'service' => 'Leo AI API',
            'version' => '2.0.0',
            'timestamp' => date('c'),
            'uptime' => $this->getUptime()
        ]);
    }
    
    private function getStats() {
        return $this->success([
            'requests_today' => $this->getRequestCount(),
            'average_response_time' => '1.2s',
            'uptime' => $this->getUptime(),
            'version' => '2.0.0'
        ]);
    }
    
    private function generateSessionId() {
        return 'Aidéo_' . uniqid() . '_' . substr(md5(uniqid()), 0, 8);
    }
    
    private function getUptime() {
        if (function_exists('sys_getloadavg')) {
            $load = sys_getloadavg();
            return number_format($load[0], 2);
        }
        return 'N/A';
    }
    
    private function getRequestCount() {
        // En production, cela viendrait d'une base de données
        return rand(100, 500);
    }
    
    private function success($data) {
        return json_encode([
            'success' => true,
            'data' => $data
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
    
    private function error($message, $code = 400) {
        http_response_code($code);
        return json_encode([
            'success' => false,
            'error' => $message,
            'code' => $code
        ], JSON_UNESCAPED_UNICODE);
    }
}

// Traitement de la requête
$api = new LeoAPI();
echo $api->handleRequest();