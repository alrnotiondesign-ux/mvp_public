/**
 * Fiches JavaScript - Fonctionnalités des fiches éducatives
 * Compatible mode clair uniquement
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialise les filtres de fiches
    initFichesFilters();
    
    // Initialise les animations des cartes
    initCardAnimations();
});

/**
 * Gère les filtres de fiches
 */
function initFichesFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const ficheCards = document.querySelectorAll('.fiche-card');
    
    if (filterButtons.length === 0 || ficheCards.length === 0) return;
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Supprime la classe active de tous les boutons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            
            // Ajoute la classe active au bouton cliqué
            this.classList.add('active');
            
            // Filtre les fiches
            const filter = this.getAttribute('data-filter');
            filterFiches(filter, ficheCards);
        });
    });
}

/**
 * Filtre les fiches selon la catégorie
 */
function filterFiches(filter, ficheCards) {
    ficheCards.forEach(card => {
        if (filter === 'all' || card.classList.contains(filter)) {
            card.style.display = 'block';
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            
            // Animation d'apparition
            setTimeout(() => {
                card.style.transition = 'all 0.3s ease';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, 50);
        } else {
            card.style.transition = 'all 0.3s ease';
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                card.style.display = 'none';
            }, 300);
        }
    });
}

/**
 * Initialise les animations des cartes
 */
function initCardAnimations() {
    const cards = document.querySelectorAll('.fiche-card, .feature-card');
    
    // Intersection Observer pour les animations au scroll
    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        });
        
        cards.forEach(card => {
            observer.observe(card);
        });
    }
}

/**
 * Affiche une notification
 */
function showNotification(message, type = 'info') {
    // Utilise la fonction showNotification de main.js si elle existe
    if (window.showNotification) {
        window.showNotification(message, type);
    } else {
        console.log(`[${type.toUpperCase()}] ${message}`);
    }
}

/**
 * Gestion du mode sombre - DÉSACTIVÉ pour le mode clair uniquement
 * Cette fonction est conservée pour compatibilité mais ne fait rien
 */
function toggleTheme() {
    console.log('Mode sombre désactivé - Mode clair uniquement');
    showNotification('Mode clair activé', 'info');
}

/**
 * Mise à jour des icônes de thème - DÉSACTIVÉ
 * Cette fonction est conservée pour compatibilité mais ne fait rien
 */
function updateThemeIcons(theme) {
    console.log(`Thème mis à jour: ${theme} (mode clair uniquement)`);
}