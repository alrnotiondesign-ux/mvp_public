// 🦁 Léo IA Financière - Version RAG Avancée pour Aidéo
// Intégration OpenAI + Base de connaissances française

class LeoAIRAG {
    constructor() {
        this.apiUrl = 'https://leo-api.Aidéo.com'; // URL de production
        this.conversationHistory = [];
        this.isInitialized = false;
        this.userContext = {};
        
        this.init();
    }
    
    async init() {
        console.log('🦁 Initialisation de Léo IA RAG...');
        this.isInitialized = true;
    }
    
    async sendMessage(message, userContext = {}) {
        try {
            // Ajouter le contexte utilisateur
            this.userContext = { ...this.userContext, ...userContext };
            
            // Préparer la requête
            const payload = {
                message: message,
                context: this.userContext,
                conversation_history: this.conversationHistory.slice(-5), // Garder les 5 derniers messages
                expertise_level: this.determineExpertiseLevel(message),
                session_id: this.generateSessionId()
            };
            
            console.log('🦁 Envoi requête à Léo IA...', { message, context: userContext });
            
            // Envoi à l'API (avec fallback en cas d'erreur)
            const response = await this.callLeoAPI(payload);
            
            if (response.success) {
                // Ajouter à l'historique
                this.conversationHistory.push({
                    user: message,
                    leo: response.answer,
                    timestamp: new Date().toISOString(),
                    context: this.userContext
                });
                
                return {
                    success: true,
                    answer: response.answer,
                    suggestions: response.suggestions || [],
                    actions: response.actions || [],
                    confidence: response.confidence || 0.9
                };
            } else {
                throw new Error(response.error || 'Erreur API');
            }
            
        } catch (error) {
            console.error('🦁 Erreur Léo IA:', error);
            
            // Fallback : système de réponses intelligentes
            return this.getFallbackResponse(message);
        }
    }
    
    async callLeoAPI(payload) {
        try {
            const response = await fetch(`${this.apiUrl}/api/chat`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(payload)
            });
            
            if (!response.ok) {
                throw new Error(`API Error: ${response.status}`);
            }
            
            return await response.json();
            
        } catch (error) {
            // En cas d'erreur réseau, utiliser le système intelligent local
            console.warn('🦁 API indisponible, utilisation du système local');
            return this.processWithLocalAI(payload);
        }
    }
    
    processWithLocalAI(payload) {
        const { message } = payload;
        const localResponses = this.getIntelligentLocalResponses();
        
        // Trouver la réponse la plus pertinente
        for (const [pattern, response] of Object.entries(localResponses.patterns)) {
            if (pattern.test(message.toLowerCase())) {
                return {
                    success: true,
                    answer: response.answer,
                    suggestions: response.suggestions || [],
                    actions: response.actions || [],
                    confidence: response.confidence || 0.7
                };
            }
        }
        
        // Réponse par défaut intelligente
        return {
            success: true,
            answer: localResponses.default.answer,
            suggestions: localResponses.default.suggestions,
            actions: localResponses.default.actions,
            confidence: 0.6
        };
    }
    
    getIntelligentLocalResponses() {
        return {
            patterns: {
                // Questions d'impôt
                /impôt.*(\d+).*€.*(célibataire|couple|enfant)/i: (match) => ({
                    answer: `Avec un revenu de ${match[1]}€, je peux estimer votre impôt. Pouvez-vous me donner plus de précisions sur votre situation familiale ? Cela m'aidera à vous donner un calcul plus précis.`,
                    suggestions: ['Revenu 30k€ célibataire', 'Revenu 50k€ couple', 'Revenu 70k€ avec enfants'],
                    confidence: 0.9
                }),
                
                // Questions micro-entreprise
                /micro.*(entreprise|auto).*(\d+).*(€|euros?)/i: (match) => ({
                    answer: `Pour un CA de ${match[2]}€, la micro-entreprise est intéressante ! Les charges sont de 22% pour les services, 12% pour le commerce. Cependant, il y a des plafonds à respecter. Je vous explique ?`,
                    suggestions: ['Seuil micro 2024', 'EURL vs Micro', 'Charges sociales'],
                    confidence: 0.9
                }),
                
                // Questions TVA
                /tva.*(franchise|régime|seuil)/i: () => ({
                    answer: `En franchise de base TVA : 37 700€ pour les services, 91 400€ pour les ventes. En dessus de ces seuils, pas de TVA à déclarer. Au dessus, régime réel obligatoire.`,
                    suggestions: ['Calcul franchise TVA', 'Régime réel simplifié', 'TVA déductible'],
                    confidence: 0.9
                }),
                
                // Questions étudiants
                /(étudiant|apprenant|études)/i: () => ({
                    answer: `En tant qu'étudiant, vous avez des avantages fiscaux intéressants ! Revenus exonérés jusqu'à 4 884€, APL pour le logement, et possibilité de déclarer'ses frais de transport.`,
                    suggestions: ['APL 2024', 'Étudiant entrepreneur', 'Frais déductibles étudiant'],
                    actions: [
                        { text: '📚 Fiche complète étudiants', url: 'fiches-content/aides-etudiantes.html' }
                    ],
                    confidence: 0.8
                }),
                
                // Questions optimisation
                /optimi(s|z)ation|économi(s|er)|réduction.*impôt/i: () => ({
                    answer: `Pour optimiser votre fiscalité, plusieurs stratégies : déclarer'se commun (si couple à revenus différents), investissement locatif (Pinel), dons aux associations (66% déductible), frais réels vs abattement.`,
                    suggestions: ['Couple à revenus différents', 'Investissement Pinel', 'Dons associations'],
                    confidence: 0.8
                })
            },
            
            default: {
                answer: "Je suis Léo, votre expert en fiscalité française. Je peux vous aider avec l'impôt sur le revenu, le choix de statut d'entreprise (micro, EURL, SASU), la TVA, et l'optimisation fiscale. Posez-moi votre question de façon précise !",
                suggestions: [
                    'Calcul impôt 40 000€',
                    'Micro vs EURL pour 30k€ ?',
                    'Seuil TVA 2024',
                    'Optimisation couple'
                ],
                actions: [
                    { text: '📊 Simulateur fiscal', url: 'dashboard.html' },
                    { text: '📚 Fiches conseils', url: 'fiches.html' }
                ],
                confidence: 0.6
            }
        };
    }
    
    determineExpertiseLevel(message) {
        const messageLower = message.toLowerCase();
        
        if (messageLower.includes('débutant') || messageLower.includes('simple') || messageLower.includes('apprenant')) {
            return 'débutant';
        }
        
        if (messageLower.includes('expert') || messageLower.includes('avancé') || messageLower.includes('optimisation')) {
            return 'expert';
        }
        
        return 'intermédiaire';
    }
    
    generateSessionId() {
        return 'Aidéo_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
    
    getFallbackResponse(message) {
        const fallbackPatterns = {
            'salut': {
                answer: "Bonjour ! Je suis Léo, votre expert fiscal Aidéo. Comment puis-je vous aider aujourd'hui ?",
                suggestions: ['Questions fiscales', 'Choix statut', 'Optimisation']
            },
            'bonjour': {
                answer: "Bonjour ! Je suis là pour vous conseiller sur la fiscalité française. Quelle est votre question ?",
                suggestions: ['Impôt sur revenu', 'Micro-entreprise', 'TVA']
            },
            'aide': {
                answer: "Je peux vous aider avec :\n\n• 📊 Calcul d'impôt\n• 🏢 Choix de statut entreprise\n• 💡 Optimisation fiscale\n• 📈 Régime TVA\n• 🏠 Questions logement",
                suggestions: ['Calculer mon impôt', 'Mon statut entreprise', 'Optimiser mes impôts']
            }
        };
        
        const messageLower = message.toLowerCase();
        for (const [pattern, response] of Object.entries(fallbackPatterns)) {
            if (messageLower.includes(pattern)) {
                return {
                    success: true,
                    answer: response.answer,
                    suggestions: response.suggestions,
                    confidence: 0.8
                };
            }
        }
        
        // Dernier recours
        return {
            success: true,
            answer: "Je suis là pour vous aider ! Pouvez-vous reformuler votre question de façon plus précise ? Je peux vous conseiller sur les impôts, statuts d'entreprise, TVA et optimisations.",
            suggestions: ['Questions impôt', 'Statut entreprise', 'Questions TVA'],
            confidence: 0.5
        };
    }
    
    // Méthodes utilitaires
    clearHistory() {
        this.conversationHistory = [];
    }
    
    getConversationSummary() {
        return {
            totalMessages: this.conversationHistory.length,
            lastActivity: this.conversationHistory[this.conversationHistory.length - 1]?.timestamp,
            sessionId: this.sessionId
        };
    }
}

// Classe de connexion API optimisée pour Hostinger
class LeoAPIConnector {
    constructor() {
        this.apiEndpoints = {
            // URLs multiples pour la résilience
            primary: 'https://leo-api.Aidéo.com',
            backup: 'https://backup-leo.Aidéo.com',
            local: 'http://localhost:8080' // Pour le développement
        };
        
        this.timeout = 10000; // 10 secondes
        this.retryCount = 2;
    }
    
    async sendRequest(message, context = {}) {
        const payloads = [
            { url: `${this.apiEndpoints.primary}/api/chat`, priority: 1 },
            { url: `${this.apiEndpoints.backup}/api/chat`, priority: 2 },
            { url: `${this.apiEndpoints.local}/api/chat`, priority: 3 }
        ];
        
        for (const payload of payloads) {
            try {
                const response = await this.tryEndpoint(payload.url, message, context);
                if (response) {
                    return response;
                }
            } catch (error) {
                console.warn(`Échec endpoint ${payload.url}:`, error.message);
            }
        }
        
        throw new Error('Tous les endpoints sont indisponibles');
    }
    
    async tryEndpoint(url, message, context) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), this.timeout);
        
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    message,
                    context,
                    client: 'Aidéo-web',
                    version: '2.0'
                }),
                signal: controller.signal
            });
            
            clearTimeout(timeoutId);
            
            if (response.ok) {
                return await response.json();
            }
            
            return null;
            
        } catch (error) {
            clearTimeout(timeoutId);
            if (error.name === 'AbortError') {
                throw new Error('Timeout de la requête');
            }
            throw error;
        }
    }
}

// Export pour utilisation dans le chat
window.LeoAIRAG = LeoAIRAG;
window.LeoAPIConnector = LeoAPIConnector;