// 🦁 Interface Chat Léo IA - Version Aidéo Optimisée
// Interface utilisateur moderne et responsive pour Léo IA

class LeoChatInterface {
    constructor(containerId = 'leo-chat') {
        this.container = document.getElementById(containerId);
        this.messagesContainer = document.getElementById('chat-messages');
        this.input = document.getElementById('chat-input');
        this.sendButton = document.getElementById('send-message');
        this.suggestionsContainer = document.getElementById('chat-suggestions');
        this.quickQuestionsContainer = document.getElementById('quick-questions');
        
        // Initialiser les composants
        this.leoAI = new LeoAIRAG();
        this.isTyping = false;
        this.isConnected = false;
        
        this.init();
    }
    
    init() {
        console.log('🦁 Initialisation interface chat Léo...');
        
        this.setupEventListeners();
        this.setupKeyboardShortcuts();
        this.showWelcomeMessage();
        this.loadQuickQuestions();
        this.testConnection();
        
        // Auto-focus sur l'input
        if (this.input) {
            setTimeout(() => this.input.focus(), 1000);
        }
        
        console.log('✅ Interface chat Léo initialisée');
    }
    
    setupEventListeners() {
        // Envoi de message
        if (this.sendButton) {
            this.sendButton.addEventListener('click', () => this.sendMessage());
        }
        
        if (this.input) {
            this.input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
            
            // Auto-resize textarea
            this.input.addEventListener('input', () => this.adjustTextareaHeight());
        }
        
        // Suggestions cliquables
        if (this.suggestionsContainer) {
            this.suggestionsContainer.addEventListener('click', (e) => {
                if (e.target.classList.contains('suggestion-btn')) {
                    const suggestion = e.target.textContent;
                    this.sendSuggestion(suggestion);
                }
            });
        }
        
        // Questions rapides
        if (this.quickQuestionsContainer) {
            this.quickQuestionsContainer.addEventListener('click', (e) => {
                if (e.target.classList.contains('quick-question')) {
                    const question = e.target.textContent;
                    this.sendMessage(question);
                }
            });
        }
    }
    
    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Ctrl+Enter pour envoyer
            if (e.ctrlKey && e.key === 'Enter' && this.input && document.activeElement === this.input) {
                e.preventDefault();
                this.sendMessage();
            }
            
            // Escape pour effacer l'input
            if (e.key === 'Escape' && this.input) {
                this.input.value = '';
                this.adjustTextareaHeight();
            }
        });
    }
    
    async testConnection() {
        try {
            this.setConnectionStatus('connecting');
            
            // Test de connexion simple
            const testResponse = await this.leoAI.sendMessage('test connexion');
            
            if (testResponse.success) {
                this.setConnectionStatus('connected');
                console.log('✅ Connexion Léo IA OK');
            } else {
                throw new Error('Réponse invalide');
            }
            
        } catch (error) {
            this.setConnectionStatus('offline');
            console.warn('⚠️ Léo IA en mode local');
        }
    }
    
    setConnectionStatus(status) {
        this.isConnected = (status === 'connected');
        const statusElement = document.getElementById('connection-status');
        
        if (statusElement) {
            statusElement.className = `connection-status ${status}`;
            
            const statusText = {
                'connecting': '🦁 Léo se connecte...',
                'connected': '🦁 Léo connecté',
                'offline': '🦁 Léo en mode local'
            }[status];
            
            statusElement.textContent = statusText;
        }
    }
    
    showWelcomeMessage() {
        if (!this.messagesContainer) return;
        
        const welcomeMessage = `
            <div class="welcome-content">
                <div class="leo-avatar">🦁</div>
                <div class="welcome-text">
                    <h3>Bonjour ! Je suis <strong>Léo</strong> 👋</h3>
                    <p>Votre expert en <strong>fiscalité française</strong> chez Aidéo.</p>
                    
                    <div class="expertise-areas">
                        <div class="expertise-item">
                            <i class="fas fa-calculator"></i>
                            <span>Calcul d'impôt</span>
                        </div>
                        <div class="expertise-item">
                            <i class="fas fa-building"></i>
                            <span>Statut entreprise</span>
                        </div>
                        <div class="expertise-item">
                            <i class="fas fa-chart-line"></i>
                            <span>Optimisation</span>
                        </div>
                        <div class="expertise-item">
                            <i class="fas fa-receipt"></i>
                            <span>TVA & Charges</span>
                        </div>
                    </div>
                    
                    <p class="welcome-hint">💡 <strong>Conseil :</strong> Soyez précis dans vos questions pour de meilleurs conseils !</p>
                </div>
            </div>
        `;
        
        this.addMessage('leo', welcomeMessage, { type: 'welcome' });
    }
    
    loadQuickQuestions() {
        const quickQuestions = [
            "💰 Calcul impôt 35 000€ célibataire",
            "🏢 Micro-entreprise pour 25 000€ CA ?",
            "💑 Optimisation couple 80 000€",
            "📊 Seuil TVA 2024",
            "👶 Quotient familial 2 enfants",
            "🎓 APL étudiant à Paris",
            "🏠 Investissement Pinel 2024",
            "📈 EURL vs SASU que choisir ?"
        ];
        
        if (this.quickQuestionsContainer) {
            this.quickQuestionsContainer.innerHTML = '';
            
            quickQuestions.forEach((question, index) => {
                const button = document.createElement('button');
                button.className = 'quick-question';
                button.innerHTML = question;
                button.style.animationDelay = `${index * 0.1}s`;
                this.quickQuestionsContainer.appendChild(button);
            });
        }
    }
    
    async sendMessage(customMessage = null) {
        const message = customMessage || this.input?.value?.trim();
        if (!message) return;
        
        // Afficher le message utilisateur
        this.addMessage('user', message);
        
        // Vider l'input
        if (this.input && !customMessage) {
            this.input.value = '';
            this.adjustTextareaHeight();
        }
        
        // Afficher l'indicateur de frappe
        this.showTypingIndicator();
        
        try {
            // Envoyer à Léo IA
            const response = await this.leoAI.sendMessage(message, this.getUserContext());
            
            // Masquer l'indicateur
            this.hideTypingIndicator();
            
            if (response.success) {
                this.addMessage('leo', response.answer, { 
                    type: 'response',
                    confidence: response.confidence 
                });
                
                // Afficher les suggestions
                if (response.suggestions && response.suggestions.length > 0) {
                    this.showSuggestions(response.suggestions);
                }
                
                // Afficher les actions
                if (response.actions && response.actions.length > 0) {
                    this.showActions(response.actions);
                }
                
            } else {
                throw new Error('Réponse invalide');
            }
            
        } catch (error) {
            console.error('Erreur sendMessage:', error);
            this.hideTypingIndicator();
            this.addMessage('leo', `
                <div class="error-message">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>Désolé, une erreur s'est produite. Pouvez-vous reformuler votre question ?</p>
                    <small>Si le problème persiste, nos conseillers Aidéo sont là pour vous aider.</small>
                </div>
            `, { type: 'error' });
        }
    }
    
    sendSuggestion(suggestion) {
        if (this.input) {
            this.input.value = suggestion;
            this.adjustTextareaHeight();
            setTimeout(() => this.sendMessage(suggestion), 100);
        }
    }
    
    addMessage(sender, content, options = {}) {
        if (!this.messagesContainer) return;
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message ${sender} ${options.type || ''}`;
        messageDiv.style.animation = 'slideInMessage 0.3s ease-out';
        
        // Avatar
        const avatar = document.createElement('div');
        avatar.className = 'avatar';
        avatar.innerHTML = sender === 'user' 
            ? '<i class="fas fa-user"></i>' 
            : '<i class="fas fa-robot"></i>';
        
        // Contenu du message
        const messageContent = document.createElement('div');
        messageContent.className = 'message';
        messageContent.innerHTML = content;
        
        // Indicateur de confiance (pour les réponses Léo)
        if (sender === 'leo' && options.confidence) {
            const confidenceIndicator = document.createElement('div');
            confidenceIndicator.className = 'confidence-indicator';
            const confidencePercent = Math.round(options.confidence * 100);
            confidenceIndicator.innerHTML = `
                <div class="confidence-bar">
                    <div class="confidence-fill" style="width: ${confidencePercent}%"></div>
                </div>
                <small>Confiance: ${confidencePercent}%</small>
            `;
            messageContent.appendChild(confidenceIndicator);
        }
        
        // Timestamp
        const timestamp = document.createElement('div');
        timestamp.className = 'timestamp';
        timestamp.textContent = new Date().toLocaleTimeString('fr-FR', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        // Assemblage
        messageDiv.appendChild(avatar);
        messageContent.appendChild(timestamp);
        messageDiv.appendChild(messageContent);
        
        this.messagesContainer.appendChild(messageDiv);
        
        // Scroll fluide
        this.scrollToBottom();
        
        // Auto-scroll pour les nouveaux messages
        if (sender === 'leo') {
            setTimeout(() => this.scrollToBottom(), 100);
        }
    }
    
    showTypingIndicator() {
        if (!this.messagesContainer || this.isTyping) return;
        
        this.isTyping = true;
        const typingDiv = document.createElement('div');
        typingDiv.className = 'chat-message leo typing';
        typingDiv.id = 'typing-indicator';
        typingDiv.style.animation = 'fadeIn 0.2s ease-out';
        
        const avatar = document.createElement('div');
        avatar.className = 'avatar';
        avatar.innerHTML = '<i class="fas fa-robot"></i>';
        
        const messageContent = document.createElement('div');
        messageContent.className = 'message';
        messageContent.innerHTML = `
            <div class="typing-content">
                <span class="typing-text">Léo réfléchit</span>
                <div class="typing-dots">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        `;
        
        typingDiv.appendChild(avatar);
        typingDiv.appendChild(messageContent);
        this.messagesContainer.appendChild(typingDiv);
        this.scrollToBottom();
    }
    
    hideTypingIndicator() {
        const typingIndicator = document.getElementById('typing-indicator');
        if (typingIndicator) {
            typingIndicator.style.animation = 'fadeOut 0.2s ease-out';
            setTimeout(() => typingIndicator.remove(), 200);
        }
        this.isTyping = false;
    }
    
    showSuggestions(suggestions) {
        if (!this.suggestionsContainer) return;
        
        this.suggestionsContainer.innerHTML = '';
        
        suggestions.forEach((suggestion, index) => {
            const button = document.createElement('button');
            button.className = 'suggestion-btn';
            button.innerHTML = suggestion;
            button.style.animationDelay = `${index * 0.1}s`;
            this.suggestionsContainer.appendChild(button);
        });
    }
    
    showActions(actions) {
        if (!this.suggestionsContainer) return;
        
        actions.forEach(action => {
            const button = document.createElement('button');
            button.className = 'action-btn';
            button.innerHTML = action.text;
            button.addEventListener('click', () => {
                if (action.url) {
                    window.open(action.url, action.target || '_self');
                }
            });
            this.suggestionsContainer.appendChild(button);
        });
    }
    
    adjustTextareaHeight() {
        if (!this.input) return;
        
        this.input.style.height = 'auto';
        this.input.style.height = Math.min(this.input.scrollHeight, 120) + 'px';
    }
    
    scrollToBottom() {
        if (this.messagesContainer) {
            this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
        }
    }
    
    getUserContext() {
        // Extraire le contexte depuis l'URL et les cookies
        const context = {
            userAgent: navigator.userAgent,
            timestamp: Date.now(),
            page: window.location.pathname
        };
        
        // Ajouter des données de session si disponibles
        const sessionData = localStorage.getItem('Aidéo_session');
        if (sessionData) {
            try {
                context.session = JSON.parse(sessionData);
            } catch (e) {
                console.warn('Impossible de parser les données de session');
            }
        }
        
        return context;
    }
    
    // Méthodes publiques pour l'intégration
    clearChat() {
        if (this.messagesContainer) {
            this.messagesContainer.innerHTML = '';
        }
        this.leoAI.clearHistory();
        this.showWelcomeMessage();
    }
    
    getChatStats() {
        return {
            messagesCount: this.messagesContainer?.children.length || 0,
            conversationSummary: this.leoAI.getConversationSummary(),
            isConnected: this.isConnected
        };
    }
}

// Styles CSS dynamiques pour l'interface
const leoChatStyles = `
<style>
.chat-message {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    margin-bottom: 16px;
    animation: slideInMessage 0.3s ease-out;
}

.chat-message .avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    flex-shrink: 0;
}

.chat-message.user .avatar {
    background: linear-gradient(135deg, #3b82f6, #1d4ed8);
    color: white;
}

.chat-message.leo .avatar {
    background: linear-gradient(135deg, #10b981, #059669);
    color: white;
}

.chat-message .message {
    background: #f8fafc;
    padding: 12px 16px;
    border-radius: 16px;
    max-width: 70%;
    position: relative;
    word-wrap: break-word;
}

.chat-message.user .message {
    background: linear-gradient(135deg, #3b82f6, #1d4ed8);
    color: white;
    margin-left: auto;
}

.chat-message.welcome .message {
    background: linear-gradient(135deg, #f0f9ff, #e0f2fe);
    border: 2px solid #3b82f6;
    color: #1e40af;
    max-width: 100%;
}

.chat-message.error .message {
    background: #fef2f2;
    border: 1px solid #ef4444;
    color: #dc2626;
}

.typing-content {
    display: flex;
    align-items: center;
    gap: 8px;
}

.typing-dots {
    display: flex;
    gap: 4px;
}

.typing-dots span {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #6b7280;
    animation: typingDots 1.4s infinite ease-in-out;
}

.typing-dots span:nth-child(1) { animation-delay: 0s; }
.typing-dots span:nth-child(2) { animation-delay: 0.2s; }
.typing-dots span:nth-child(3) { animation-delay: 0.4s; }

.suggestion-btn, .action-btn, .quick-question {
    background: linear-gradient(135deg, #f0f9ff, #e0f2fe);
    border: 1px solid #3b82f6;
    color: #1e40af;
    padding: 8px 12px;
    border-radius: 8px;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.2s ease;
    margin: 4px;
}

.suggestion-btn:hover, .action-btn:hover, .quick-question:hover {
    background: linear-gradient(135deg, #3b82f6, #1d4ed8);
    color: white;
    transform: translateY(-1px);
}

.connection-status {
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 500;
}

.connection-status.connected {
    background: #d1fae5;
    color: #065f46;
}

.connection-status.offline {
    background: #fef3c7;
    color: #92400e;
}

.confidence-indicator {
    margin-top: 8px;
    padding-top: 8px;
    border-top: 1px solid #e5e7eb;
}

.confidence-bar {
    width: 100%;
    height: 4px;
    background: #e5e7eb;
    border-radius: 2px;
    overflow: hidden;
    margin-bottom: 4px;
}

.confidence-fill {
    height: 100%;
    background: linear-gradient(90deg, #ef4444, #f59e0b, #10b981);
    transition: width 0.3s ease;
}

.expertise-areas {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 8px;
    margin: 16px 0;
}

.expertise-item {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 14px;
    color: #4b5563;
}

.expertise-item i {
    color: #3b82f6;
}

.welcome-hint {
    font-size: 13px;
    color: #6b7280;
    font-style: italic;
    margin-top: 8px;
}

@keyframes slideInMessage {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes typingDots {
    0%, 60%, 100% {
        transform: scale(0.8);
        opacity: 0.5;
    }
    30% {
        transform: scale(1);
        opacity: 1;
    }
}

@media (max-width: 768px) {
    .chat-message .message {
        max-width: 85%;
    }
    
    .expertise-areas {
        grid-template-columns: 1fr;
    }
}
</style>
`;

// Initialisation automatique
document.addEventListener('DOMContentLoaded', function() {
    // Ajouter les styles
    document.head.insertAdjacentHTML('beforeend', leoChatStyles);
    
    // Initialiser le chat si le conteneur existe
    if (document.getElementById('leo-chat')) {
        window.leoChat = new LeoChatInterface();
        console.log('🦁 Léo Chat Interface initialisé !');
    }
});

// Export pour usage externe
window.LeoChatInterface = LeoChatInterface;