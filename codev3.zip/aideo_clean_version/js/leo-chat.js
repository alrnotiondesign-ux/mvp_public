// Léo AI Chat System avec IA Fiscale

class IAExpertFiscal {
    constructor() {
        this.expertise = {
            impots_revenu: this.expertiseImpotsRevenu(),
            tva: this.expertiseTVA(),
            is: this.expertiseImpotSocietes(),
            micro_entreprise: this.expertiseMicroEntreprise(),
            immobilier: this.expertiseImmobilier()
        };
        
        this.reglesFiscales = this.chargerReglesFiscales();
    }

    expertiseImpotsRevenu() {
        return {
            bareme_2024: [
                { tranche: 0, limite: 11294, taux: 0 },
                { tranche: 1, limite: 28797, taux: 0.11 },
                { tranche: 2, limite: 82341, taux: 0.30 },
                { tranche: 3, limite: 177106, taux: 0.41 },
                { tranche: 4, limite: Infinity, taux: 0.45 }
            ],
            parts_familiales: {
                celibataire: 1,
                couple: 2,
                enfant1: 0.5,
                enfant2: 0.5,
                enfant3: 1
            }
        };
    }

    expertiseTVA() {
        return {
            taux: {
                normal: 0.20,
                intermediaire: 0.10,
                reduit: 0.055,
                particulier: 0.021
            },
            franchises: {
                vente: 91400,
                services: 37700
            }
        };
    }

    expertiseMicroEntreprise() {
        return {
            seuils_2024: {
                services: 77700,
                vente: 188700,
                liberale: 77700
            },
            charges: {
                services: 0.22,
                vente: 0.12,
                liberale: 0.22
            }
        };
    }

    chargerReglesFiscales() {
        return {
            "impot_revenu": [
                {
                    condition: (data) => data.revenu < 16176,
                    conseil: "Votre revenu est en dessous du seuil de première tranche, vous ne devriez pas payer d'impôt sur le revenu.",
                    action: "Vérifiez votre éligibilité à la décote."
                },
                {
                    condition: (data) => data.enfants >= 3,
                    conseil: "Vous bénéficiez d'une majoration du quotient familial pour vos 3 enfants ou plus.",
                    action: "Pensez à déclarer tous vos enfants à charge."
                }
            ],
            "choix_statut": [
                {
                    condition: (data) => data.ca_prevu < 37700 && data.activite === 'services',
                    conseil: "La micro-entreprise semble adaptée pour votre activité de services.",
                    avantages: ["Simplicité administrative", "Charges sociales proportionnelles au CA"],
                    inconvenients: ["Plafond de CA limité", "Protection sociale réduite"]
                },
                {
                    condition: (data) => data.ca_prevu > 70000,
                    conseil: "L'EURL ou SASU serait plus adaptée pour votre niveau de CA prévu.",
                    avantages: ["Pas de plafond de CA", "Protection sociale complète", "Possibilité d'optimisation"],
                    inconvenients: ["Comptabilité plus lourde", "Charges fixes"]
                }
            ]
        };
    }

    analyserSituationFiscale(question, donneesUtilisateur) {
        try {
            const contexte = this.analyserContexte(question);
            const reglesApplicables = this.trouverReglesApplicables(contexte, donneesUtilisateur);
            const recommandations = this.genererRecommandations(reglesApplicables, donneesUtilisateur);
            
            return {
                contexte: contexte,
                analyse: this.fournirAnalyseDetaillee(contexte, donneesUtilisateur),
                recommandations: recommandations,
                actions: this.proposerActionsConcretes(recommandations),
                succes: true
            };
        } catch (error) {
            return {
                succes: false,
                erreur: "Désolé, une erreur s'est produite lors de l'analyse.",
                contexte: 'general'
            };
        }
    }

    analyserContexte(question) {
        const questionLower = question.toLowerCase();
        
        if (questionLower.includes('micro') || questionLower.includes('auto') || questionLower.includes('statut')) {
            return 'choix_statut';
        } else if (questionLower.includes('tva')) {
            return 'tva';
        } else if (questionLower.includes('impôt') || questionLower.includes('revenu') || questionLower.includes('tranche')) {
            return 'impot_revenu';
        } else if (questionLower.includes('optim') || questionLower.includes('économie')) {
            return 'optimisation';
        } else {
            return 'general';
        }
    }

    trouverReglesApplicables(contexte, donnees) {
        const reglesDomaine = this.reglesFiscales[contexte] || [];
        return reglesDomaine.filter(regle => {
            try {
                return regle.condition(donnees);
            } catch (error) {
                return false;
            }
        });
    }

    genererRecommandations(reglesApplicables, donnees) {
        return reglesApplicables.map(regle => ({
            conseil: regle.conseil,
            avantages: regle.avantages || [],
            inconvenients: regle.inconvenients || [],
            urgence: 'moyenne',
            action: regle.action || ''
        }));
    }

    fournirAnalyseDetaillee(contexte, donnees) {
        const analyses = {
            'impot_revenu': () => {
                if (donnees.revenu) {
                    return `Avec un revenu de ${donnees.revenu}€, votre impôt dépend de votre situation familiale.`;
                }
                return "Pour calculer votre impôt, j'ai besoin de connaître votre revenu annuel.";
            },
            'choix_statut': () => {
                if (donnees.ca_prevu) {
                    if (donnees.ca_prevu < 37700) {
                        return `Avec un CA prévu de ${donnees.ca_prevu}€, la micro-entreprise est recommandée pour sa simplicité.`;
                    } else {
                        return `Avec un CA prévu de ${donnees.ca_prevu}€, l'EURL ou SASU est préférable.`;
                    }
                }
                return "Pour vous conseiller sur le statut, j'ai besoin de connaître votre chiffre d'affaires prévu.";
            }
        };

        return analyses[contexte] ? analyses[contexte]() : "Analyse de votre situation fiscale.";
    }

    proposerActionsConcretes(recommandations) {
        return recommandations.map(rec => ({
            action: `📝 ${rec.conseil}`,
            delai: 'à planifier',
            priorite: 'moyenne'
        }));
    }
}

// Système de réponses de base
const leoResponses = {
    'salut': {
        response: "Bonjour ! Je suis Léo, votre expert en fiscalité française. Comment puis-je vous aider aujourd'hui ?",
        suggestions: ['Calcul impôt', 'Choix statut', 'Optimisation', 'Questions TVA']
    },
    'bonjour': {
        response: "Bonjour ! Je suis Léo, spécialiste en fiscalité française. Posez-moi vos questions sur les impôts, statuts d'entreprise ou optimisations.",
        suggestions: ['Impôt sur le revenu', 'Micro-entreprise', 'Déclaration', 'Aides']
    },
    'impôt': {
        response: "Je peux vous aider avec les impôts ! Pour un calcul précis, pouvez-vous me dire votre revenu annuel et votre situation familiale ?",
        suggestions: ['Revenu 30 000€ célibataire', 'Revenu 50 000€ couple', 'Revenu 70 000€ avec enfants']
    },
    'calcul': {
        response: "Je peux estimer votre impôt. Quel est votre revenu annuel et votre situation familiale ?",
        suggestions: ['25 000€ célibataire', '45 000€ couple', '60 000€ avec 2 enfants']
    },
    'micro': {
        response: "La micro-entreprise est idéale pour débuter ! Quel est votre chiffre d'affaires prévu et votre type d'activité ?",
        suggestions: ['CA 20 000€ services', 'CA 50 000€ commerce', 'CA 80 000€ libéral']
    },
    'tva': {
        response: "Le régime TVA dépend de votre chiffre d'affaires. En micro-entreprise, franchise jusqu'à 37 700€ pour les services.",
        suggestions: ['Franchise en base', 'Régime réel', 'Déductibilité TVA']
    },
    'étudiant': {
        response: "En tant qu'étudiant, vous avez des avantages spécifiques ! Revenus exonérés jusqu'à 4 884€ par an, et aides au logement.",
        actions: [
            { text: '🎓 Voir la fiche étudiante', url: 'fiches-content/aides-etudiantes.html' },
            { text: '🧮 Simuler mes aides', url: 'demo-leo.html' }
        ]
    },
    'apl': {
        response: "Les APL dépendent de vos revenus, loyer et situation. En moyenne : 100-250€ en résidence universitaire, 150-400€ en appartement.",
        actions: [
            { text: '🧮 Simuler mes APL', url: 'demo-leo.html' },
            { text: '📖 Fiche complète', url: 'fiches-content/aides-etudiantes.html' }
        ]
    },
    'déclaration': {
        response: "Je vous guide pour votre déclaration ! Célibataire = 1 part, Couple = 2 parts, +0.5 part par enfant.",
        suggestions: ['Première déclaration', 'Déclaration couple', 'Déclaration avec enfants']
    },
    'optimisation': {
        response: "Plusieurs stratégies d'optimisation existent : déclaration commune, investissement immobilier, dons aux associations (66% déductible).",
        suggestions: ['Couple à revenus différents', 'Investissement Pinel', 'Dons associations']
    },
    'default': {
        response: "Je suis Léo, votre expert fiscal. Je peux vous aider avec : impôts, choix de statut entreprise, optimisation fiscale, TVA, et bien plus ! Posez-moi une question précise.",
        suggestions: ['Calcul impôt', 'Micro vs EURL', 'Optimisation couple', 'Questions TVA']
    }
};

class LeoChat {
    constructor() {
        this.chatContainer = document.getElementById('leo-chat');
        this.messagesContainer = document.getElementById('chat-messages');
        this.input = document.getElementById('chat-input');
        this.sendButton = document.getElementById('send-message');
        this.suggestionsContainer = document.getElementById('chat-suggestions');
        this.iaFiscale = new IAExpertFiscal();
        
        this.init();
    }
    
    init() {
        if (this.sendButton) {
            this.sendButton.addEventListener('click', () => this.sendMessage());
        }
        if (this.input) {
            this.input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.sendMessage();
                }
            });
        }
        
        // Show welcome message
        this.addMessage('leo', "👋 Bonjour ! Je suis <strong>Léo</strong>, votre expert en fiscalité française. Je peux vous aider avec :<br><br>• 📊 <strong>Calcul d'impôt</strong> sur le revenu<br>• 🏢 <strong>Choix de statut</strong> (micro-entreprise, EURL...)<br>• 💡 <strong>Optimisation fiscale</strong><br>• 📈 <strong>Régime TVA</strong><br><br>Posez-moi votre question en français !");
        this.showSuggestions(['Calcul impôt 40 000€', 'Micro-entreprise ou EURL ?', 'Optimisation pour couple', 'Seuil TVA 2024']);
    }
    
    sendMessage() {
        const message = this.input.value.trim();
        if (!message) return;
        
        // Add user message
        this.addMessage('user', message);
        this.input.value = '';
        
        // Show typing indicator
        this.showTypingIndicator();
        
        // Process message with AI
        setTimeout(() => {
            this.hideTypingIndicator();
            this.processMessage(message);
        }, 1000 + Math.random() * 1000);
    }
    
    processMessage(message) {
        const lowerMessage = message.toLowerCase();
        
        // Détection des questions fiscales complexes
        if (this.estQuestionFiscaleComplexe(lowerMessage)) {
            this.traiterQuestionFiscaleComplexe(message);
            return;
        }
        
        // Réponses de base
        let response = leoResponses.default;
        
        for (const [keyword, data] of Object.entries(leoResponses)) {
            if (lowerMessage.includes(keyword)) {
                response = data;
                break;
            }
        }
        
        this.addMessage('leo', response.response);
        
        if (response.suggestions) {
            this.showSuggestions(response.suggestions);
        }
        
        if (response.actions) {
            this.showActions(response.actions);
        }
    }
    
    estQuestionFiscaleComplexe(message) {
        const motifsComplexes = [
            /\d+.*euros?.*célibataire/i,
            /\d+.*euros?.*couple/i,
            /\d+.*euros?.*enfant/i,
            /ca.*\d+.*euros?/i,
            /chiffre.*affaires.*\d+/i,
            /micro.*\d+.*euros?/i,
            /eurl.*\d+.*euros?/i,
            /statut.*\d+.*euros?/i
        ];
        
        return motifsComplexes.some(motif => motif.test(message));
    }
    
    traiterQuestionFiscaleComplexe(message) {
        const donnees = this.extraireDonneesMessage(message);
        const analyse = this.iaFiscale.analyserSituationFiscale(message, donnees);
        
        if (analyse.succes) {
            let reponseHTML = `<strong>${analyse.analyse}</strong><br><br>`;
            
            if (analyse.recommandations && analyse.recommandations.length > 0) {
                reponseHTML += "<strong>💡 Mes recommandations :</strong><br>";
                analyse.recommandations.forEach(rec => {
                    reponseHTML += `• ${rec.conseil}<br>`;
                    if (rec.avantages.length > 0) {
                        reponseHTML += `<small>✅ Avantages : ${rec.avantages.join(', ')}</small><br>`;
                    }
                });
            }
            
            if (analyse.actions && analyse.actions.length > 0) {
                reponseHTML += "<br><strong>🎯 Actions :</strong><br>";
                analyse.actions.forEach(action => {
                    reponseHTML += `• ${action.action}<br>`;
                });
            }
            
            this.addMessage('leo', reponseHTML);
            this.showSuggestions(['Autre calcul', 'Questions TVA', 'Optimisation', 'Aides sociales']);
        } else {
            this.addMessage('leo', "Je n'ai pas pu analyser votre demande. Pouvez-vous reformuler avec des chiffres précis ? Ex: 'Quel impôt pour 45 000€ célibataire ?'");
            this.showSuggestions(['Exemple de question', 'Calcul impôt', 'Choix statut']);
        }
    }
    
    extraireDonneesMessage(message) {
        const donnees = {
            revenu: this.extraireNombre(message, /(\d+)\s*(?:euros?|€)/i),
            ca_prevu: this.extraireNombre(message, /ca.*?(\d+)\s*(?:euros?|€)/i) || this.extraireNombre(message, /chiffre.*affaires.*?(\d+)/i),
            situation: this.extraireSituation(message),
            enfants: this.extraireEnfants(message),
            activite: this.extraireActivite(message)
        };
        
        return donnees;
    }
    
    extraireNombre(message, regex) {
        const match = message.match(regex);
        return match ? parseInt(match[1]) : null;
    }
    
    extraireSituation(message) {
        if (message.includes('célibataire') || message.includes('seul')) return 'celibataire';
        if (message.includes('couple') || message.includes('marié') || message.includes('pacse')) return 'couple';
        return 'celibataire';
    }
    
    extraireEnfants(message) {
        if (message.includes('3 enfants') || message.includes('trois enfants')) return 3;
        if (message.includes('2 enfants') || message.includes('deux enfants')) return 2;
        if (message.includes('1 enfant') || message.includes('un enfant')) return 1;
        if (message.includes('enfant')) return 1;
        return 0;
    }
    
    extraireActivite(message) {
        if (message.includes('service') || message.includes('conseil') || message.includes('libéral')) return 'services';
        if (message.includes('commerce') || message.includes('vente')) return 'vente';
        return 'services';
    }
    
    addMessage(sender, text) {
        if (!this.messagesContainer) return;
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message ${sender}`;
        
        const avatar = document.createElement('div');
        avatar.className = 'avatar';
        avatar.textContent = sender === 'user' ? '👤' : '🤖';
        
        const messageContent = document.createElement('div');
        messageContent.className = 'message';
        messageContent.innerHTML = text;
        
        messageDiv.appendChild(avatar);
        messageDiv.appendChild(messageContent);
        this.messagesContainer.appendChild(messageDiv);
        
        // Scroll to bottom
        this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
    }
    
    showTypingIndicator() {
        if (!this.messagesContainer) return;
        
        const typingDiv = document.createElement('div');
        typingDiv.className = 'chat-message leo typing';
        typingDiv.id = 'typing-indicator';
        
        const avatar = document.createElement('div');
        avatar.className = 'avatar';
        avatar.textContent = '🤖';
        
        const messageContent = document.createElement('div');
        messageContent.className = 'message';
        messageContent.innerHTML = '<div class="typing-dots"><span></span><span></span><span></span></div>';
        
        typingDiv.appendChild(avatar);
        typingDiv.appendChild(messageContent);
        this.messagesContainer.appendChild(typingDiv);
        this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
    }
    
    hideTypingIndicator() {
        const typingIndicator = document.getElementById('typing-indicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }
    
    showSuggestions(suggestions) {
        if (!this.suggestionsContainer) return;
        
        this.suggestionsContainer.innerHTML = '';
        
        suggestions.forEach(suggestion => {
            const button = document.createElement('button');
            button.className = 'suggestion-btn';
            button.textContent = suggestion;
            button.addEventListener('click', () => {
                if (this.input) {
                    this.input.value = suggestion;
                    this.sendMessage();
                }
            });
            this.suggestionsContainer.appendChild(button);
        });
    }
    
    showActions(actions) {
        if (!this.suggestionsContainer) return;
        
        actions.forEach(action => {
            const button = document.createElement('button');
            button.className = 'action-btn';
            button.innerHTML = action.text;
            button.addEventListener('click', () => {
                window.location.href = action.url;
            });
            this.suggestionsContainer.appendChild(button);
        });
    }
}

// Questions rapides pour la démo
const quickQuestions = [
    "Calcul impôt 35 000€ célibataire",
    "Micro-entreprise pour 25 000€ CA ?", 
    "Optimisation couple 80 000€",
    "Seuil TVA 2024",
    "Quotient familial 2 enfants",
    "APL étudiant Paris"
];

function initQuickQuestions() {
    const container = document.getElementById('quick-questions');
    if (!container) return;
    
    quickQuestions.forEach(question => {
        const button = document.createElement('button');
        button.className = 'quick-question';
        button.textContent = question;
        button.addEventListener('click', () => {
            const chatInput = document.getElementById('chat-input');
            if (chatInput) {
                chatInput.value = question;
                document.getElementById('send-message').click();
            }
        });
        container.appendChild(button);
    });
}

// Initialisation
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('leo-chat')) {
        new LeoChat();
    }
    initQuickQuestions();
    
    console.log('🤖 Léo IA Fiscalité initialisé avec succès !');
});